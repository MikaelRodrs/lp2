﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        double raio, altura, volume;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
   
        }

        private void Limpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text ="";
            txtRaio.Text= string.Empty;
            txtVolume.Clear();
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out raio)
                || (raio <=0))
            {
                MessageBox.Show("raio invalido");
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Calcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out raio)
                || (raio <= 0))
            {
                MessageBox.Show("raio invalido");
                txtRaio.Focus();    
            }
            else if (!double.TryParse(txtAltura.Text, out altura)
                || (altura <= 0))
            {
                MessageBox.Show("Altura inválida");
                txtAltura.Focus();
            }
            else
            {
                volume= Math.PI * Math.Pow(raio,2)* altura;
                txtVolume.Text = volume.ToString("N2");
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura)
                || (altura <= 0))
            {
                MessageBox.Show("Altura inválida");
            }
        }

       

        private void Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
